import polars as pl


class ggb_cp:
    _pl = pl
    _pl.Config.set_tbl_rows(-1)

    def __init__(self):
        pass

    def load(self, file):
        self.cp = pl.read_parquet(file)
        self.cp = (self.cp
            .transpose(include_header=True, header_name="Name", column_names=["Type", "Command", "Value", "Caption", "Layer"])
            .with_columns(pl.col("Layer").cast(pl.Int64).fill_null(0)))
        return self

    def save(self, file):
        self.cp.write_parquet(file)
        return self